const hamburger = document.querySelector(".hamburger");    //Retourne '.hamburger' dans le document qui correspond au sélécteur 
const navMenu = document.querySelector(".nav-menu");          //Retourne '.nav-menu' dans le document qui correspond au sélécteur

hamburger.addEventListener("click", () => {               //Permet de clicker sur le 'bar' pour activer le menu burger
hamburger.classList.toggle("active");                       //va permettre a la famille hamburger d'effectuer leur codage dans css
navMenu.classList.toggle("active");                          //Affiche le menu burger 
})


